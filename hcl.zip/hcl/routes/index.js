
/*
 * GET home page.
 */
 
var Users = require('../models/users.js');
//DYNAMIC HELPER FOR SESSION
module.exports = function(app) {
app.dynamicHelpers({
session: function(req, res) {
return req.session;
}
});
//RENDER BY DEFAULT LOGIN PAGE
app.get('/', function(req, res){
if(req.session.userid){
res.render('index');
}else{
res.redirect('/sign-in');	
}
});
//RENDER SIGN IN PAGE
app.get('/sign-in', function(req, res){
res.render('signin', {})
});
//LOGOUT FROM HCL APPLICATION
app.get('/sign-out', function(req, res, next) {
req.session.destroy();
res.redirect('/sign-in');
});
};
