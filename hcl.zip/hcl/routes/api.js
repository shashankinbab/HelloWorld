/*
*  Routes
*/
var UserNumbers = require('../models/usernumber.js');
module.exports = function(app,io){
    // get all counts of logged in users  
    app.get('/api/getusercounter', function(req, res) {
        if(req.session.userid){ //check if user login
        UserNumbers.count({'UserID':req.session.userid},function(err, NumberData) {
        if (err)res.send(err)
            var returnjson = { error :false ,count:NumberData, msg:'Earlier tried count'}
            res.json(returnjson); // return count of numbers saved in JSON format
        });
        }else{
        var returnjson = { error :true, msg:'You must be logged in to test'}
        res.json(returnjson); // return response in JSON format        
        }
    });
    //save number in database and get post data
    app.post('/api/savenumber', function(req,res){
        if(req.session.userid){ //check if user login
        counter ={'usernumber':req.body.number, UserID: req.session.userid };
        var UserNumbersObj = new UserNumbers(counter);
        UserNumbersObj.save(function(err, rawResponse) {});
        var returnjson = { error :false, msg:'Number saved successfully'}
        res.json(returnjson); // return response in JSON format
        }else{
        var returnjson = { error :true, msg:'You must be logged in to test'}
        res.json(returnjson); // return response in JSON format    
        }
    });
    };
