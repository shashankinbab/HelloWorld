/*
* User Routes
*/

var Users = require('../models/users.js');
module.exports = function(app,io){
    // Main Route  for sign in user
    app.post('/users/signin', function(req,res){
	Users.findOne({username:req.body.username},function(err,result){
		if(err){ throw err; }
        if (result) {
        req.session.user = req.body.username;
        req.session.userid = result._id;
        res.redirect('/');
        res.end();    
        }else{
        var userData ={ 'username': req.body.username}   
        var UserObj = new Users(userData);
        UserObj.save(err,function(){}); 
        Users.findOne({username:req.body.username},function(err,result){
        if(err){ throw err; }
        if (result) {
        req.session.user = req.body.username;
        req.session.userid = result._id;
        req.session.admin = result.admin;
        res.redirect('/');
        res.end();
        }
        });
       }
	});
    });
};