var mongoose = require('mongoose');
var Schema = mongoose.Schema, ObjectId= Schema.ObjectId;
module.exports = mongoose.model('Users', new Schema({ username: String }), 'Users'); 
