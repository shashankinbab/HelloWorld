var mongoose = require('mongoose');
var Schema = mongoose.Schema, ObjectId= Schema.ObjectId;
module.exports = mongoose.model('UserNumbers',  new Schema({ usernumber: Number,UserID: ObjectId}), 'UserNumbers'); 
