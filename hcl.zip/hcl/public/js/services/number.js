angular.module('numberService', [])
	// super simple service
	// each function returns a promise object 
	.factory('Todos', ['$http',function($http) {
		return {
			savevalue : function(numberData) {
				return $http.post('/api/savenumber',numberData,{timeout: 5000});
			},
			getusercount: function(){
				return $http.get('/api/getusercounter',{timeout: 5000});
			}
		}
	}]);