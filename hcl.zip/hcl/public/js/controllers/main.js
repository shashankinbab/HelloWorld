angular.module('formController', [])
	// inject the Todo service factory into our controller
	.controller('mainController', ['$scope','$http','Todos', function($scope, $http, Todos) {
		$scope.formData = {};
		$scope.minvalue = 30; //minimum value
		$scope.maxvalue = 40; //maximum value
		$scope.validnumber = 35; // valid number
		$scope.user = {};// default user form empty
		$scope.allowedCount = 3; // allowed counter
		$scope.retmessage = ""; //default return message
		$scope.showmessage = false; //default show message for displaying messages
	
		//function to get total count of logged in user 
		$scope.loadCount = function(){
		Todos.getusercount()
		.success(function(data) {
			if(!data.error){
				var remainingcount = parseInt($scope.allowedCount) - parseInt(data.count) ;
				$scope.attemptcount = remainingcount > 0?remainingcount:0;
			}else{
				$scope.retmessage = data.msg;
				$scope.showmessage = true;	
			}
		})
		.error(function(data, status) {
			$scope.retmessage = "Server not reponding. Please try after some time";
			$scope.showmessage = true;
		});
		}
		$scope.loadCount();

		//function to save number in database 
		$scope.saveform = function(form){
			if($scope.attemptcount>0){ // to chcek if count not exceeded
			Todos.savevalue($scope.user)
			.success(function(data) {
				$scope.loadCount();
				if(!data.error){
					if(parseInt($scope.user.number) == parseInt($scope.validnumber)){
						$scope.retmessage = "Congratulations! Number matched";
						$scope.showmessage =true;
					}else{
						$scope.retmessage = "Sorry! Number not matched";
						$scope.showmessage =true;
					}		
				}else{
					$scope.retmessage = data.msg;
					$scope.showmessage = true;	
				}
			}).error(function(data, status) {
				$scope.retmessage = "Server not reponding. Please try after some time";
				$scope.showmessage = true;
  			});
  			}else{
  				$scope.retmessage = "Sorry! You have reached maximum number of allowed limits";
				$scope.showmessage =true;	
  			};
		}
	}]);