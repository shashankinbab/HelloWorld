angular.module('hclApp', ['formController', 'numberService']);
